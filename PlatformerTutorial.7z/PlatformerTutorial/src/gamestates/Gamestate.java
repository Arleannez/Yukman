package gamestates;

public enum Gamestate {

	PLAYING, MENU, QUIT;

	public static Gamestate state = MENU;

}
